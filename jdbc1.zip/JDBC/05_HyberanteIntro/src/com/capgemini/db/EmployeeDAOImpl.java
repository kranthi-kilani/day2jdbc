package com.capgemini.db;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.business.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public boolean addEmployee(Employee employee) {

		try {
			EntityManagerFactory emf = Persistence
					.createEntityManagerFactory("JPA-PU");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(employee);
			em.getTransaction().commit();
			return true;

		} catch (Exception e) {

			return false;
		}

	}

	@Override
	public boolean removeEmployee(int id) {
		// TODO Auto-generated method stub
		try {
			EntityManagerFactory emf = Persistence
					.createEntityManagerFactory("JPA-PU");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			Employee e = findEmployee(106);
			em.remove(e);
			em.getTransaction().commit();
			emf.close();
			em.close();
			return true;

		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public boolean updateEmployee(Employee employee) {

		try {
			EntityManagerFactory emf = Persistence
					.createEntityManagerFactory("JPA-PU");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			em.merge(106);
			em.getTransaction().commit();
			emf.close();
			em.close();
			return true;

		} catch (Exception e) {
			return false;
		}

	}

	@Override
	public Employee findEmployee(int id) {
		Employee e = null;
		try {
			EntityManagerFactory emf = Persistence
					.createEntityManagerFactory("JPA-PU");
			EntityManager em = emf.createEntityManager();
			e = em.find(Employee.class, id);
			emf.close();
			em.close();
			return e;
		} catch (Exception e1) {
			return e;
		}

	}

	@Override
	public List<Employee> getEmployees() {
		List<Employee> empList = null;
		try {
			EntityManagerFactory emf = Persistence
					.createEntityManagerFactory("JPA-PU");
			EntityManager em = emf.createEntityManager();
			Query q = em.createQuery("from Employee");
			empList = q.getResultList();
			emf.close();
			em.close();
			return empList;

		} catch (Exception e) {

			return empList;
		}

	}

}
