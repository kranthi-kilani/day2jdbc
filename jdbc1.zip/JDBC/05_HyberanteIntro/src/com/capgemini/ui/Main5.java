package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.business.Contact;

public class Main5 {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();

		Contact contact1 = new Contact(111, "Rohit", "9168578545");
		Contact contact2 = new Contact(112, "Prabhas", "9868577865");
		Contact contact3 = new Contact(113, "Ajay", "8385678345");
		em.getTransaction().begin();
		/*em.persist(contact1);// still attached object;
		em.persist(contact2);
		em.persist(contact3);*/
		em.getTransaction().commit();
		contact3.setPhno("9876543210");
		em.merge(contact3);
		em.close();
		emf.close();
		// contact3.setId(114);------->detached state,changes made does not
		// affect to the database
		Contact contact4 = null;
		emf = Persistence.createEntityManagerFactory("JPA-PU");
		em = emf.createEntityManager();
		contact4 = em.find(Contact.class, 111);//in persistence state
		contact4.setPhno("1234567890");
		em.merge(contact4);
		System.out.println(contact4.equals(contact1));
		em.getTransaction().begin();
		em.persist(contact4);
		em.getTransaction().commit();
		em.close();
		emf.close();
		
		
	}

}
