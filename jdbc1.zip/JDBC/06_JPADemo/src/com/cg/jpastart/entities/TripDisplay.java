package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TripDisplay {
	public static void main(String[] args) {
	
		SeatInfo seat = new SeatInfo(15, 20, 15);
		Trip trip = new Trip();
		trip.setFrom_city("chennai");
		trip.setTo_city("mumbai");
		trip.setInfo(seat);
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		em.persist(trip);
		
		Trip trip1=em.find(Trip.class,1);
		System.out.println(trip);
		System.out.println(trip.getInfo());
		em.getTransaction().commit();
		em.close();
		factory.close();
	
	}

}
