package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class StudentMain {
	

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		/*Student student = new Student();
		student.setName("Deepak Patil");
		Address homeAddress = new Address();
		homeAddress.setStreet("MG Road");
		homeAddress.setCity("Pune");
		homeAddress.setState("Maharashtra");
		homeAddress.setZipCode("411 017");
		student.setAddress(homeAddress);
*/
	
		em.getTransaction().commit();
		Address address=em.find(Address.class, 1);
		em.remove(address);
		/*Address address=em.find(Address.class, 1);
		System.out.println(address.getAddressId()+" " +address.getCity()+""+address.getState()+""+address.getStreet()+""+address.getZipCode());;
	     Student student=em.find(Student.class, 2);
	     System.out.println(student.getName()+""+student.getAddress().getCity()+" "+student.getAddress().getZipCode));(*/
		em.close();
		factory.close();
	}

}
